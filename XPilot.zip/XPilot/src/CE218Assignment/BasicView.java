package CE218Assignment;


import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.LinkedList;


/**
 * Created by zyangf on 21/01/14.
 */
public class BasicView extends JComponent{
    AsteroidsAIGame game;

    Vector2D center;
    Image im = Constants.MILKYWAY1;
    AffineTransform bgTransf;
    LinkedList<GameObject> particles;
    int times = 0;


    public BasicView(AsteroidsAIGame game){
        this.game = game;
        double imWidth = im.getWidth(null);
        double imHeight = im.getHeight(null);
        double stretchx = (imWidth > Constants.FRAME_WIDTH? 1 :
                Constants.FRAME_WIDTH/imWidth);
        double stretchy = (imHeight > Constants.FRAME_HEIGHT? 1 :
                Constants.FRAME_HEIGHT/imHeight);

        bgTransf = new AffineTransform();
        bgTransf.scale(stretchx, stretchy);


    }

    @Override

    public void paintComponent(Graphics g0){
        Graphics2D g = (Graphics2D) g0;
        AffineTransform t0 = g.getTransform();

        g.drawImage(im, bgTransf, null);
        g.setColor(Color.white);
        g.drawString("score:" + game.getScore(), 10, 10);
        g.drawString("Lives:"+game.getLives(), 10, 20);
        g.setColor(Color.cyan);
        g.setFont(new Font("Agency FB", Font.PLAIN, 30));
        g.drawString("Cannon: "+game.getMyship().shootcannon,10,50);
        g.setColor(Color.red);
        g.setFont(new Font("Agency FB", Font.PLAIN, 50));
        g.drawString("Level: "+game.getLevel(), 10, 100);
        g.setColor(new Color(224,255,255));
        g.drawRect(550,20,800,35);
        g.drawRect(550, 20,160, 35);
        g.drawRect(710, 20, 160, 35);
        g.drawRect(870, 20, 160, 35);
        g.drawRect(1030, 20,160,35);
        switch(game.myship.barriercount){
            case 5:
                g.setColor(new Color(0,191,255,95));
                g.fillRect(1190,20,160,35);
            case 4:
                g.setColor(new Color(0,191,255,95));
                g.fillRect(1030, 20,160,35);
            case 3:
               // g.drawRect(870, 20, 160, 35);
                g.setColor(new Color(0,191,255,95));
                g.fillRect(870, 20, 160, 35);
            case 2:
                g.setColor(new Color(0,191,255,95));
                g.fillRect(710, 20, 160, 35);
            case 1:
                g.setColor(new Color(0,191,255,95));
                g.fillRect(550, 20,160, 35);


}


        if(!game.ctrl.action(game).gameStart){
            if(times%2==0){
                g.setColor(Color.yellow);
                g.setFont(new Font("Jing Jing",Font.PLAIN,80));
                g.drawString("Asteroids", Constants.FRAME_WIDTH/3, Constants.FRAME_HEIGHT/6);
            }
            try{
                Thread.sleep(400);
            }catch (Exception e){
                e.printStackTrace();
            }
            times++;
            this.repaint();
            g.setColor(Color.white);
            g.setFont(new Font("Calibri (Body)", Font.PLAIN, 30));
            g.drawString("By ZhuoLin Yang 1204853", Constants.FRAME_WIDTH/3, 480);
            g.setColor(Color.red);
            g.setFont(new Font("Quartz MS", Font.PLAIN, 50));
            g.drawString("Put Button S to Start", Constants.FRAME_WIDTH/3, 600);
            g.drawString("Put Button H get Help", Constants.FRAME_WIDTH/3, 750);
            g.setColor(Color.cyan);
            g.setFont(new Font("Quartz MS", Font.PLAIN, 50));
            g.drawString("Put Button Esc to exit Game", Constants.FRAME_WIDTH/3,850);
        }
        if(game.ctrl.action(game).safegame){
            g.setColor(Color.cyan);
            g.setFont(new Font("Quartz MS", Font.PLAIN, 100));
            g.drawString("Pause", Constants.FRAME_WIDTH/3, Constants.FRAME_HEIGHT/2);
            repaint();
        }
        if(game.gameOver){
            g.setColor(Color.cyan);
            g.setFont(new Font("Quartz MS", Font.PLAIN, 100));
            g.drawString("GameOver", Constants.FRAME_WIDTH/3, Constants.FRAME_HEIGHT/2);
            g.drawString("Your Scores are: "+game.getScore() , Constants.FRAME_WIDTH/4, Constants.FRAME_HEIGHT/3);
            g.drawString("Put Button Esc to exit", Constants.FRAME_WIDTH/4, Constants.FRAME_HEIGHT/4);

        }
        else if(game.ctrl.action(game).gameStart){

            synchronized (game) {
                for (GameObject object : game.objects) {
                    object.draw(g);
                }
            }
        }
        synchronized (game) {
            for (GameObject p : game.getParticles())
                p.draw(g);
        }


        g.setTransform(t0);

    }


}
