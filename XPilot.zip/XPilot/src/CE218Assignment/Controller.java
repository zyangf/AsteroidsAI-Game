package CE218Assignment;;

/**
 * Created by zyangf on 05/03/14.
 */
public interface Controller {
    public Action action(Game game);
}

//public interface BasicController {
//    public Action action();
//}

