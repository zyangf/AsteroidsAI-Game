package CE218Assignment;;

import java.awt.*;
import java.awt.geom.AffineTransform;

import static CE218Assignment.Constants.FRAME_WIDTH;

/**
 * Created by zyangf on 07/03/14.
 */
public class BasicEnemyShip extends GameObject {
    static final int RADIUS = 40;
    static final double STEER_RATE = 2* Math.PI;  // in radians per second
    Vector2D center;

    // magnitude of acceleration when thrust is applied
    static final double MAG_ACC = 200;

    // constant speed loss factor
    static final double LOSS =0.99;

    static int lastshoot = 0;

    static final Color COLOR = Color.green;


    static final int[] XP = new int[]{0, -4, 0, 4};
    static final int[] YP = new int[] {0, -2, 5, -2};
    Game game;


    // direction in which ship is turning
    // this is a "unit" vector (so magnitude is 1)
    Vector2D d;

    Controller ctrl2;

    public BasicEnemyShip(Game game, Controller ctrl2) {
        s = new Vector2D();
        v = new Vector2D();
        d = new Vector2D();
        this.game = game;

        this.ctrl2 = ctrl2;
        reset();
    }

    public void reset() {
        // Until vector
        if(game.gameOver){
            dead = true;
        }else{
            s.set(Math.random() * (FRAME_WIDTH - 2 * RADIUS), Math.random() * (FRAME_WIDTH - 2 * RADIUS));
            v.set(0, 0);//not moving
            d.set(0,1);
            dead = false;
        }

    }

    public void update() {
        Action action = ctrl2.action(game);
        d.rotate(action.turn*STEER_RATE*Constants.DT);
        v.add(d, MAG_ACC*Constants.DT*action.thrusting * -1);
        v.mult(LOSS);
        s.add(v, Constants.DT);

        s.wrap(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);
        if(action.shoot && lastshoot == 0){
            shootBullet();
            lastshoot = 10;
        }
        if (lastshoot > 0){
            lastshoot-=1;
        }

    }

    public void draw(Graphics2D g){
        Action action = ctrl2.action(game);
        AffineTransform at = g.getTransform();
        g.translate(s.x, s.y);
        double rot = d.theta() + Math.PI / 2;
        g.rotate(rot);
        g.scale(5, 5);
        g.setColor(COLOR);
        g.fillPolygon(XP, YP, XP.length);

        if (action.isThrusting){
        }
        g.setTransform(at);

    }

    private void shootBullet(){
        Vector2D bV = new Vector2D(v);
        bV.add(d, -200);
        Vector2D bS = new Vector2D(s);
        bS.add(d, -Radius()-1);
        EnemyBullet b = new EnemyBullet(this.game,bS, bV);
        game.add(b);
        SoundManager.fire();
        SoundManager.play(SoundManager.fire);
    }



    public double Radius() {
        // TODO Auto-generated method stub
        return RADIUS;
    }


    public void hit() {
      dead = true;

    }
    public void hit2(){
        dead = true;

    }

    @Override
    public double dist(GameObject obj) {
        return s.dist(obj.s);
    }

    @Override
    public Vector2D to(GameObject target) {
        return new Vector2D(target.v.x-this.v.x, target.v.y-this.v.y);
    }

    @Override
    public double radius() {
        return 0;
    }

}
