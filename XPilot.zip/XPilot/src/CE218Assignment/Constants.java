package CE218Assignment;

import java.awt.*;
import java.io.IOException;
import java.util.Random;

/**
 * Created by zyangf on 21/01/14.
 */
public class Constants {
	public static final Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    public static final int FRAME_HEIGHT = dim.height;
    public static final int FRAME_WIDTH = dim.width;
    public static final int WORLD_WIDTH = 3000;//3000
    public static final int WORLD_HEIGHT = 3500;//3500
    public static final Dimension FRAME_SIZE = new Dimension(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);
    public static final int DELAY = 20;
    public static final double DT = DELAY / 1000.0;
    public static final Random RANDOM = new Random();
    // number of asteroids on 1st level
    public static final int N_INITIAL_ASTEROIDS = 1;
    
    public static Image ASTEROID1, MILKYWAY1;
	static {
	  try {
	    ASTEROID1 = ImageManager.loadImage("asteroid1");
	    MILKYWAY1 = ImageManager.loadImage("milkyway2");
	  } catch (IOException e) { 
		  e.printStackTrace();
		  System.exit(1); }
	}
}
