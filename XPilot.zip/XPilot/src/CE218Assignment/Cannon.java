package CE218Assignment;

import static CE218Assignment.Constants.DT;

import java.awt.*;

import static CE218Assignment.Constants.*;

public class Cannon extends GameObject{
	int ti = 100;


    public Cannon(Game g, Vector2D s, Vector2D v) {
		super(g, s, v);
		dead = false;
	}
	
	public void draw(Graphics2D g) {
        int x = (int) s.x;
        int y = (int) s.y;
        g.setColor(Color.RED);
        g.fillOval((int)(x - Radius())+20, (int)(y - Radius())-10, (int)(2 * Radius())+20, (int)(2 * Radius())+20);

    }
	  public void update(){
	        s.x +=v.x * DT;
	        s.y +=v.y * DT;
	        s.x = (s.x + WORLD_WIDTH) % WORLD_WIDTH;
	        s.y = (s.y + WORLD_HEIGHT) % WORLD_HEIGHT;
	        ti--;
	        if (ti < 0){
	        	dead = true;
	        }
	    }

    public void hit(){
        dead = true;
    }
	  public void hit2(){
		  dead = true;

      }

    @Override
    public double dist(GameObject obj) {
        return s.dist(obj.s);
    }

    @Override
    public Vector2D to(GameObject target) {
        return new Vector2D(target.v.x-this.v.x, target.v.y-this.v.y);
    }

    @Override
    public double radius() {
        return 0;
    }


    public double Radius() {
		// TODO Auto-generated method stub
		return 5;
	}
}
	