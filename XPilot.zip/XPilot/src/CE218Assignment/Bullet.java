package CE218Assignment;;

import static CE218Assignment.Constants.DT;

import java.awt.Color;
import java.awt.Graphics2D;

import static CE218Assignment.Constants.*;

public class Bullet extends GameObject{
	int ti = 120;
	
	public Bullet(Game g, Vector2D s, Vector2D v) {	
		super(g, s, v);
		dead = false;
	}
	
	public void draw(Graphics2D g) {
        int x = (int) s.x;
        int y = (int) s.y;
        g.setColor(Color.yellow);
        g.fillOval((int)(x - Radius()), (int)(y - Radius()), (int)(2 * Radius()), (int)(2 * Radius())); 

    }
	  public void update(){
	        s.x +=v.x * DT;
	        s.y +=v.y * DT;
	        s.x = (s.x + WORLD_WIDTH) % WORLD_WIDTH;
	        s.y = (s.y + WORLD_HEIGHT) % WORLD_HEIGHT;
	        ti--;
	        if (ti < 0){
	        	dead = true;
	        }
	    }
	
	  public void hit(){
          this.game.addScore();
		  dead = true;
	  }
    public void hit2(){
        dead = true;
    }

    @Override
    public double dist(GameObject obj) {
        return s.dist(obj.s);
    }

    @Override
    public Vector2D to(GameObject target) {
        return new Vector2D(target.v.x-this.v.x, target.v.y-this.v.y);
    }

    @Override
    public double radius() {
        return 0;
    }

    @Override
	public double Radius() {
		// TODO Auto-generated method stub
		return 2;
	}


	
	

}
