package CE218Assignment;;

import javax.swing.*;

import java.awt.*;

/**
 * Created with IntelliJ IDEA.
 * User: zyangf
 * Date: 21/01/14
 * Time: 16:14
 * To change this template use File | Settings | File Templates.
 */
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;


public class JEasyFrame extends JFrame {
	public final static GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
	public final static GraphicsDevice device = env.getScreenDevices()[0]; 
	public static final Rectangle RECTANGLE = device.getDefaultConfiguration().getBounds(); 
	public static final int WIDTH = RECTANGLE.width; 
	public static final int HEIGHT = RECTANGLE.height; 
	
	public Component comp;


	public JEasyFrame(Component comp, String title) {

		super();
		this.comp = comp;
      //  this.comp.setForeground(Color.black);
		getContentPane().add(BorderLayout.CENTER, comp);
		comp.setPreferredSize(new Dimension (WIDTH, HEIGHT));
//        this.setBackground(Color.black);
//        this.setForeground(Color.black);
		this.setUndecorated(true);
		pack();
		this.setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		repaint();
	}


}
//public class JEasyFrame extends JFrame {
//    public Component comp;
//    public JEasyFrame(Component comp, String title){
//        super(title);
//        this.comp=comp;
//        getContentPane().add(BorderLayout.CENTER, comp);
//        pack();
//        this.setVisible(true);
//        setDefaultCloseOperation(EXIT_ON_CLOSE);
//        repaint();
//    }
//
//}
