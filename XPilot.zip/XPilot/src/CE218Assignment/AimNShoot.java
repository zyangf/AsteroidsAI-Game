package CE218Assignment;;

/**
 * Created by zyangf on 05/03/14.
 */
public class AimNShoot implements Controller {

    public static final double SHOOTING_DISTANCE = 150;
    public static final double SHOOTING_ANGLE = Math.PI / 12;
    GameObject target;
    Action action = new Action();
    BasicEnemyShip ship;
   // BasicEnemyShip ship2;



    @Override
    public Action action(Game game) {
        GameObject nextTarget = findTarget(game.getGameObject());
        if (nextTarget == null)
            return new Action();
        switchTarget(nextTarget);
        aim();
        action.thrusting = 1;
        action.shoot = ((Math.abs(angleToTarget()) < SHOOTING_ANGLE)
                && inShootingDistance());
        return action;
    }


    public GameObject findTarget(Iterable<GameObject> gameObjects){
        double minDistance = 2 * SHOOTING_DISTANCE;
        GameObject closestTarget = null;
        for (GameObject obj : gameObjects) {
            if (obj == ship || obj instanceof EnemyBullet || obj instanceof BasicAsteroid)
                continue;
            double dist = ship.dist(obj);
            if (dist < minDistance) {
                closestTarget = obj;
                minDistance = dist;
            }
        }
        return closestTarget;
    }

    public double angleToTarget() {
        Vector2D v = ship.to(target);
        v.rotate(-ship.d.theta());
        return v.theta();
    }




    public boolean inShootingDistance() {
        return ship.dist(target) < SHOOTING_DISTANCE + target.radius(); }

    public void aim() {
        double angle = angleToTarget();
        action.turn = (int) Math.signum(Math.sin(angle));
    }

    public void switchTarget(GameObject newTarget) {
        target = newTarget;
    }
}
