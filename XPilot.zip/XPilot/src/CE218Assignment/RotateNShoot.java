package CE218Assignment;;

/**
 * Created by zyangf on 05/03/14.
 */
public class RotateNShoot implements Controller{
    Action action = new Action();
    @Override
    public Action action(Game game) {
        action.shoot = true;
        action.turn = 1;
        return action;

    }  }
