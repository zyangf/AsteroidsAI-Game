package CE218Assignment;;

import java.awt.Color;
import java.awt.Graphics2D;

public class Particle extends GameObject {
	  public static final int RADIUS = 1;
	  public  Color color = Color.gray;
	  double ttl;


	  public Particle(Game game, Vector2D s, double ttl, Color color) {
	    super(game, new Vector2D(s), 
	        new Vector2D(Constants.RANDOM.nextGaussian(),
	        Constants.RANDOM.nextGaussian()));
	    this.ttl = ttl;
	    this.color = color; 
	  }



    @Override
	  public void update() {
	    s.add(v);
	    v.mult(0.99);
	    ttl--;
	    if (ttl < 0) dead = true; 
	  }

	  @Override
	  public void draw(Graphics2D g) {
	    g.setColor(color);
	    g.fillOval((int) s.x - RADIUS, (int) s.y - RADIUS, 
	                2 * RADIUS, 2 * RADIUS);
	  }


	  @Override
	  public double Radius() {
	    return RADIUS;
	  }


	@Override
	public void hit() {
		// TODO Auto-generated method stub
		
	}
    public void hit2(){

    }

    @Override
    public double dist(GameObject obj) {
        return s.dist(obj.s);
    }

    @Override
    public Vector2D to(GameObject target) {
        return new Vector2D(target.v.x-this.v.x, target.v.y-this.v.y);
    }

    @Override
    public double radius() {
        return 0;
    }

}