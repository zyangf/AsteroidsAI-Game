package CE218Assignment;

public class Action {
	public int thrusting;
	public int turn;
	public boolean shoot;
	public boolean cannon;
	public boolean isThrusting;
	boolean safegame;
    boolean gameStart;
}




