package CE218Assignment;;

import java.awt.event.*;

import CE218Assignment.Action;

public class BasicKeys extends KeyAdapter implements Controller  {
    Action action;
    public BasicKeys() {
        action = new Action();
    }

    public Action action(Game game){return action;}
    public Action action() {
        // this is defined to comply with the standard interface
        return action;
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        switch (key) {
            case KeyEvent.VK_UP:
                action.thrusting = 1;
                action.isThrusting = true;
                break;
            case KeyEvent.VK_LEFT:
                action.turn = -1;
                break;
            case KeyEvent.VK_RIGHT:
                action.turn = +1;
                break;
            case KeyEvent.VK_SPACE:
                action.shoot = true;
                break;
            case KeyEvent.VK_Z:
                action.cannon = true;
                //BasicShip.lastshoot2=0;
                break;
            case KeyEvent.VK_D:
                if(action.safegame)
                    action.safegame=false;
                else{
                    action.safegame=true;
                }
                break;
            case KeyEvent.VK_S:
//                if(action.gameStart){
//                    action.gameStart = false;
//                }else {
                    action.gameStart=true;
                SoundManager.start();
                SoundManager.play(SoundManager.start );
               // }
                break;
            case KeyEvent.VK_H:
                Help h= new Help();
                break;
            case KeyEvent.VK_ESCAPE:
                System.exit(1);

        }
    }

    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();
        switch (key) {
            case KeyEvent.VK_UP:
                action.thrusting = 0;
                action.isThrusting = false;
                break;
            case KeyEvent.VK_LEFT:
                action.turn = 0;
                break;
            case KeyEvent.VK_RIGHT:
                action.turn = 0;
                break;
            case KeyEvent.VK_SPACE:
                action.shoot =false;
                break;
            case KeyEvent.VK_Z:
                action.cannon = false;
                //BasicShip.lastshoot2=0;
                break;
        }
    }

}

