package CE218Assignment;; /**
 * Created by zyangf on 21/01/14.
 */
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;

import static CE218Assignment.Constants.*;

public class BasicAsteroid extends GameObject{
    public static final int RADIUS = 105;
    public static final double MAX_SPEED = 100;
    Image im = Constants.ASTEROID1;
    AffineTransform bgTransf;
    double width = RADIUS, height=RADIUS, direction;
    Vector2D center;
  

    public BasicAsteroid(){
    	super();
    	dead = false;

    }

    public BasicAsteroid(Game g, double sx, double sy, double vx, double vy){
    	super(g, new Vector2D(sx,sy), new Vector2D(vx,vy));      
    }

    public static BasicAsteroid makeRandomAsteroid(Game g) {
        double sx = RADIUS + Math.random() * (FRAME_WIDTH - 2 * RADIUS);
        double sy = RADIUS + Math.random() * (FRAME_HEIGHT - 2 * RADIUS);
        double vx = Math.random() * MAX_SPEED;
        double vy = Math.random() * MAX_SPEED;
        BasicAsteroid basicAsteroid = new BasicAsteroid(g, sx, sy, vx, vy);
        return basicAsteroid;
    }

    public void update(){
        s.x +=v.x * DT;
        s.y +=v.y * DT;
        s.x = (s.x + FRAME_WIDTH) % FRAME_WIDTH;
        s.y = (s.y + FRAME_HEIGHT) % FRAME_HEIGHT;

    }
    
    

    public void draw(Graphics2D g) {

    	double imW = im.getWidth(null);
    	double imH = im.getHeight(null);
    	AffineTransform bgTransf = new AffineTransform();
    	bgTransf.rotate(direction, 0, 0);
    	bgTransf.scale(width/imW, height/imH);
    	bgTransf.translate(-imW/2.0, -imH/2.0);

    	AffineTransform t0 = g.getTransform();
    	g.translate(s.x, s.y);
        g.drawImage(im, bgTransf,null);
        g.setTransform(t0);
    }

	@Override
	public double Radius() {
		// TODO Auto-generated method stub
		return (width + height)/4.0;
	}

	@Override
	public void hit() {
		width = width/2;
		height = height/2;
		v.mult(-1);
		if(width <= 20|| height <= 20) 
			dead=true;
		else{
	        double vx = Math.random() * MAX_SPEED;
	        double vy = Math.random() * MAX_SPEED;
	        BasicAsteroid basicAsteroid = new BasicAsteroid(game, s.x, s.y, vx, vy);
	        basicAsteroid.width = width;
	        basicAsteroid.height = height;
	        game.add(basicAsteroid);
		}
	}
    public void hit2(){
        this.game.addScore();
        dead = true;

    }

    @Override
    public double dist(GameObject obj) {
        return s.dist(obj.s);
    }

    @Override
    public Vector2D to(GameObject target) {
        return new Vector2D(target.v.x-this.v.x, target.v.y-this.v.y);
    }

    @Override
    public double radius() {
        return 0;
    }
}

