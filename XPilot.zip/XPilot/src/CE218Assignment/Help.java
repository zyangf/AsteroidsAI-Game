package CE218Assignment;;

import javax.swing.*;

/**
 * Created by zyangf on 03/03/14.
 */
class Help extends JFrame {
    JList jl=null;
    public Help() {
        String s[]={"UP Key--Move;\n  Left Key--left-handed rotation;\n Right-Key-handed rotation;\n Space--Shot;\n Z--Cannon;\n D--pause;\n "};
        jl=new JList(s);

        this.add(jl);
        this.setSize(700, 300);
        this.setVisible(true);

    }
}
 

