package CE218Assignment;;

import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;


/**
 * Created by zyangf on 05/03/14.
 */
public class AsteroidsAIGame implements Game {
    BasicEnemyShip ship;
    BasicKeys ctrl;
    BasicShip myship;
    AimNShoot ctrl2;


    ArrayList<GameObject> objects;
    ArrayList<GameObject> pending;
    ArrayList<GameObject> alive;
    LinkedList<GameObject> particles;


    int score = 0;
    int lives = 5;
    int level = 1;
    int asteroidcount = 5;
    int AIcount =2;
    boolean safegame = false;
    boolean gameOver = false;
    boolean levelup = false;
    boolean gameStart = false;


    public static void main(String[] args) throws Exception {

        AsteroidsAIGame game = new AsteroidsAIGame();

        BasicView view = new BasicView(game);
        SoundManager.load();
        new JEasyFrame(view, "Basic Game").addKeyListener(game.ctrl);
        // run the game
        game.Safe();
        while(!game.gameStart){
            game.update();
            view.repaint();
            Thread.sleep(Constants.DELAY);
        }
        while (!game.safegame) {
            game.update();
            view.repaint();
            Thread.sleep(Constants.DELAY);
        }
    }


    public void Safe() {
        while (!checkSafeGame()) {
            for (GameObject otherObject : objects) {
                otherObject.update();
            }
        }
    }

    public boolean checkSafeGame() {
        for (GameObject otherObject : objects) {
            if (!(otherObject instanceof BasicShip) && this.myship.s.dist(otherObject.s) <= this.myship.Radius() + otherObject.Radius() + 100) {
                return false;
            }
            if (!(otherObject instanceof BasicEnemyShip) && this.ship.s.dist(otherObject.s) <= this.ship.Radius() + otherObject.Radius() + 100) {
                return false;
            }

        }
        return true;

    }

    public void level() {

        if(!gameOver){
            if (myship.dead) {
                myship.reset();
                SoundManager.extraShip();
                SoundManager.play(SoundManager.extraShip );
                objects.add(myship);
                Safe();
            }
        }


        if (asteroidcount <= 0 && !gameOver) {

            addLevel();
            levelup = true;
            if (ship.dead) {
                ship.reset();
                objects.add(ship);
            }

            myship.barriercount = 5;
            asteroidcount += level * 5;
            AIcount +=1;

            myship.shootcannon = 10;
            for (int i = 0; i < asteroidcount; i++) {
                BasicAsteroid sast = BasicAsteroid.makeRandomAsteroid(this);
                if (this.myship.s.dist(sast.s) < this.myship.Radius() + 200) {
                    sast.s.add(this.myship.Radius() + 200, this.myship.Radius() + 200);
                }
                if (this.ship.s.dist(sast.s) < this.ship.Radius() + 200) {
                    sast.s.add(this.ship.Radius() + 200, this.ship.Radius() + 200);
                }
            }
            myship.reset();
            Safe();
            restGame();

        } else {
            if (lives <= 0) {
                gameOver = true;
            }
        }

    }


    public void restGame() {

        ship.reset();
        myship.reset();

        for (int i = 0; i < asteroidcount; i++) {
            objects.add(BasicAsteroid.makeRandomAsteroid(this));
        }
        for (int i = 0; i < AIcount; i++){
            AimNShoot c = new AimNShoot();
            c.ship = ship;
            objects.add(new BasicEnemyShip(this,c));
        }
    }

    public AsteroidsAIGame() {
        objects = new ArrayList<GameObject>();
        pending = new ArrayList<GameObject>();
        alive = new ArrayList<GameObject>();
        particles = new LinkedList<GameObject>();

        ctrl2 = new AimNShoot();
        ctrl = new BasicKeys();

        ship = new BasicEnemyShip(this, ctrl2);


        ctrl2.ship = ship;
        objects.add(ship);


        myship = new BasicShip(this, ctrl);

        objects.add(myship);

        for (int i = 0; i < asteroidcount; i++) {
            BasicAsteroid sast = BasicAsteroid.makeRandomAsteroid(this);
            if (this.myship.s.dist(sast.s) < this.myship.Radius() + 200) {
                sast.s.add(this.myship.Radius() + 200, this.myship.Radius() + 200);
            }
            objects.add(BasicAsteroid.makeRandomAsteroid(this));
        }
    }

    public void update() {
        updateParticles();
        Action action = this.ctrl.action(this);
       if(action .gameStart){
        if (!action.safegame) {
            if (lives <= 0) {
                gameOver = true;
            }

            for (GameObject object : objects) {
                object.update();
                if(gameStart){
                    object.dead = true;
                    objects.clear();
                }
                if (gameOver) {
                    object.dead = true;
                }
                if (object instanceof BasicShip || object instanceof BasicAsteroid || object instanceof BasicEnemyShip)
                    checkCollision(object);
                if (!object.dead)
                    alive.add(object);
                else {
                    if (object instanceof BasicAsteroid) {
                        asteroidcount--;
                    }
                }

            }


            synchronized (this) {
                objects.clear();
                objects.addAll(pending);
                objects.addAll(alive);
            }
            pending.clear();
            alive.clear();
            level();
        }
    }
   }



    public void checkCollision(GameObject object) {
        // check with other game objects
        if (!object.dead) {
            for (GameObject otherObject : objects) {
                if (object.getClass() != otherObject.getClass()
                        && overlap(object, otherObject)) {
                    // the object's hit, and the other is also
                    if (object instanceof EnemyBullet) {
                        if (otherObject instanceof BasicShip) {
                            object.hit();
                            otherObject.hit();
                            return;
                        } else if (otherObject instanceof BasicAsteroid || otherObject instanceof BasicEnemyShip) {
                            object.hit();
                            return;
                        }
                    }
                    if(object instanceof BasicEnemyShip && otherObject instanceof EnemyBullet){
                        ship.dead =false;
                    }
                    if(object instanceof BasicEnemyShip && otherObject instanceof Bullet||object instanceof BasicEnemyShip && otherObject instanceof BasicShip){
                        object.hit();
                        otherObject.hit();

                            if(object instanceof BasicEnemyShip || otherObject instanceof BasicEnemyShip){
                                explosion(object.s, 300, 200, Color.green);
                            }
                            score+=1;

                        return;

                    }
                    if (object instanceof BasicAsteroid && otherObject instanceof Cannon || object instanceof BasicEnemyShip && otherObject instanceof Cannon) {

                        object.hit2();
                        otherObject.hit2();
                        score += 4;

                        if (object instanceof BasicAsteroid || otherObject instanceof BasicAsteroid || object instanceof BasicEnemyShip || otherObject instanceof BasicEnemyShip) {
                            explosion(object.s, 300, 200, Color.red);
                        }

                    } else {
                        object.hit();
                        otherObject.hit();
                    }
                    SoundManager.asteroids();
                    SoundManager.play(SoundManager.bangMedium );

                    if (object instanceof BasicShip && otherObject instanceof BasicAsteroid || object instanceof BasicAsteroid && otherObject instanceof BasicShip
                            || object instanceof BasicShip && otherObject instanceof BasicEnemyShip || object instanceof BasicEnemyShip && otherObject instanceof BasicShip
                            || object instanceof EnemyBullet && otherObject instanceof BasicShip || object instanceof BasicShip && otherObject instanceof EnemyBullet ) {
                        if(myship.barriercount > 0){
                            if (object instanceof BasicShip || otherObject instanceof BasicShip) {
                                explosion(object.s, 100, 200, Color.cyan);
                            }
                            myship.barriercount--;

                        }else if(myship.barriercount == 0){
                            if (object instanceof BasicShip || otherObject instanceof BasicShip) {
                                 explosion(object.s, 1000, 200, Color.orange);
                             }
                             lives--;
                            score-=3;
                        }
                    }

                    if(object instanceof BasicEnemyShip && otherObject instanceof BasicAsteroid || object instanceof BasicAsteroid && otherObject instanceof BasicEnemyShip){
                        ship.dead =false;
                   }

                    if (object instanceof BasicAsteroid || otherObject instanceof BasicAsteroid) {
                        explosion(object.s, 100, 200, Color.gray);
                    }
                    return;
                }

            }
        }
    }

    public boolean overlap(GameObject x, GameObject y) {

        return x.s.dist(y.s) <= x.Radius() + y.Radius();
    }


    public void add(GameObject object) {
        pending.add(object);
        if (object instanceof BasicAsteroid)
            asteroidcount += 1;
    }

    @Override
    public Iterable<GameObject> getGameObject() {
        // TODO Auto-generated method stub
        return this.objects;
    }

    @Override
    public int getScore() {

        // TODO Auto-generated method stub
        return score;
    }

    @Override
    public void addScore() {
        score += 1;
        // TODO Auto-generated method stub
    }

    @Override
    public int getLives() {
        // TODO Auto-generated method stub
        return lives;
    }

    @Override
    public void addLives() {
        lives -= 1;
    }

    @Override
    public void removeLives() {
        lives--;

    }

    public int getLevel() {
        return level;
    }

    public void addLevel() {
        level++;
    }

    public BasicEnemyShip getShip() {
        return ctrl2.ship;
    }

    public BasicShip getMyship() {
        return myship;
    }


    public void explosion(Vector2D s, int n, int ttl, Color color) {
        for (int i = 0; i < n; i++)
            particles.add(new Particle(this, s, (1 + Math.random() * ttl), color));
    }

    public void updateParticles() {
        // iterate over the set of particles, removing any dead ones
        ListIterator<GameObject> it = particles.listIterator();
        synchronized (this) {
            while (it.hasNext()) {
                Particle p = (Particle) it.next();
                p.update();
                if (p.dead) {
                    it.remove();
                }
            }
        }
    }

    public Iterable<GameObject> getParticles() {
        // TODO Auto-generated method stub
        return particles;
    }

    public Vector2D getShipLocation() {
        return ctrl2.ship.s;
    }


}
