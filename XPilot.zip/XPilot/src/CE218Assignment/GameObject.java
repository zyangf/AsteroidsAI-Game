package CE218Assignment;;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RectangularShape;

public abstract class GameObject {
	protected Game game;
	protected Vector2D v, s;
	protected boolean dead;
	
	public GameObject(){
		
	}
	
	public GameObject(Game g, Vector2D s2, Vector2D v2){
		 this.game = g;
		 this.v = v2;
		 this.s = s2;
	} 
	
	
	
	public abstract double Radius();
	public abstract void update();
	public abstract void draw(Graphics2D g);

	public abstract void hit();
    public abstract void hit2();

    public abstract double dist(GameObject obj);

    public abstract Vector2D to(GameObject target);

    public abstract double radius();

    // note the direction: it is from this vector to the argument vector v
    public Vector2D to(Vector2D v) {
        return new Vector2D(s.x-this.s.x, s.y-this.s.y);
    }

}
