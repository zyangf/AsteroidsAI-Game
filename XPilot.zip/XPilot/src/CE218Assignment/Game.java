package CE218Assignment;;

public interface Game{
    boolean gameOver = false;

    public Iterable<GameObject>getGameObject();
	public void add(GameObject obj);	
	public int getScore();
	public void addScore();
	public int getLives();
	public void addLives();
	public void removeLives();
	
}