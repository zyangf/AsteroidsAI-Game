package CE218Assignment;;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class BasicShip extends GameObject{
    static final int RADIUS = 40;
    static final double STEER_RATE = 2* Math.PI;  // in radians per second
    int barriercount = 5;
    boolean barrier = false;
    Vector2D center;

    int shootcannon = 10;

    // magnitude of acceleration when thrust is applied
    static final double MAG_ACC = 200;

    // constant speed loss factor 
    static final double LOSS =0.99;
    
    static int lastshoot = 0;
    static int lastshoot2 = 0;
                                        
    static final Color COLOR = Color.GRAY;
    
    static final int[] XP = new int[]{-1, -5, -5, -1, -1, 1, 1, 5, 5, 1, 1, 3, 3, -3, -3, -1};
    static final int[] YP = new int[]{0, 1, -2, -2, -4, -4, -2, -2, 1, 0, 4, 4, 6, 6, 4, 4};
//    static final int[] XP = new int[]{0, -1, 0, 1}; 
//    static final int[] YP = new int[] {0, -1, 1, -1};
    static final int[] XPTHRUST = new int[]{-1, -1, 1, 1};
    static final int[] XPTHRUST2 = new int[]{-5, -5, -3, -3};
    static final int[] XPTHRUST3 = new int[]{5, 5, 3, 3};
    static final int[] YPTHRUST = new int[]{-4, -6, -4, -6};
    static final int[] YPTHRUST2 = new int[]{-2, -4, -2, -4};
    static final int[] YPTHRUST3 = new int[]{-2, -4, -2, -4};
    
    static final int[] XPTHRUST4 = new int[]{-1, 1, -1, 1};
    static final int[] YPTHRUST4 = new int[]{5, 5, 6, 6};
    static final int[] XPTHRUST5 = new int[]{-3, -3, -1, 1};
    static final int[] YPTHRUST5 = new int[]{0, -2, 0, -2};
    static final int[] XPTHRUST6 = new int[]{3, 3, 1, -1};
    static final int[] YPTHRUST6 = new int[]{0, -2, 0, -2};
    Game game;
   
    
    // direction in which ship is turning
    // this is a "unit" vector (so magnitude is 1) 
    Vector2D d;
    
    Controller ctrl;

    public BasicShip(Game game, Controller ctrl) {
    s = new Vector2D();
    v = new Vector2D();
    d = new Vector2D(); 
      this.game = game;
      
      this.ctrl = ctrl;
      reset();
    }

   public void reset() {
//       s.set(Constants.FRAME_WIDTH /2 - center.x, Constants.FRAME_HEIGHT/2 - center.y);
	   // Until vector
       if(game.gameOver){
           dead = true;
       }else{
           s.set(Constants.FRAME_WIDTH/2, Constants.FRAME_HEIGHT/2);
           v.set(0,0);//not moving
           d.set(0,1);
           dead = false;
       }

   }

   public void update() { 
	   Action action = ctrl.action(game);
//	   Action action = this.game.ctrl.action();
	   d.rotate(action.turn*STEER_RATE*Constants.DT);
	   v.add(d, MAG_ACC*Constants.DT*action.thrusting * -1);
	   v.mult(LOSS);
	   s.add(v, Constants.DT);
	   //s.wrap(Constants.WORLD_WIDTH, Constants.WORLD_HEIGHT);
       s.wrap(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);
	   if(action.shoot && lastshoot == 0){
		   shootBullet();
	   		lastshoot = 10;
	   }
	   if (lastshoot > 0){
		   lastshoot-=1;
	   }
	   if(action.cannon && lastshoot2 == 0){
		   YAMATOcannon();
		   lastshoot2 = 80;
	   }
	   if (lastshoot2 > 0){
		   lastshoot2-=1;
	   }
//       if(barriercount==5000){
//           revive = true;
//       }
//       while(barriercount==0){
//           revived+=1;
//           if (revived ==1000){
//               barriercount=1000;
//           }
//           if(revived == 2000){
//               barriercount=2000;
//           }
//           if(revived == 3000){
//               barriercount=3000;
//           }
//           if(revived == 4000){
//               barriercount = 4000;
//           }
//           if(revived == 5000){
//               barriercount = 5000;
//               revived = 0;
//           }
//       }



   }


   
   public void draw(Graphics2D g){
	   Action action = ctrl.action(game);
	   AffineTransform at = g.getTransform();
	   g.translate(s.x, s.y);
	   double rot = d.theta() + Math.PI / 2;
	   g.rotate(rot);
	   g.scale(5, 5);
	   g.setColor(COLOR);
	   g.fillPolygon(XP, YP, XP.length);
       drawBarrier(g);
	   
	if (action.isThrusting){
		   g.setColor(Color.orange);
		  // g.fillOval(1, 1, 1, 1);
		   g.fillPolygon(XPTHRUST, YPTHRUST, XPTHRUST.length);
		   g.fillPolygon(XPTHRUST2, YPTHRUST2, XPTHRUST2.length);
		   g.fillPolygon(XPTHRUST3, YPTHRUST3, XPTHRUST3.length);
		   SoundManager.startThrust();
		   SoundManager.play(SoundManager.thrust);


	   }
	 if (action.isThrusting){
		   g.setColor(Color.red);
		  // g.fillOval(1, 1, 1, 1);
		   g.fillPolygon(XPTHRUST4, YPTHRUST4, XPTHRUST4.length);
		  
	   }
	 if (action.isThrusting){
		   g.setColor(Color.CYAN);
		  // g.fillOval(1, 1, 1, 1);
		   g.fillPolygon(XPTHRUST5, YPTHRUST5, XPTHRUST5.length);
		   g.fillPolygon(XPTHRUST6, YPTHRUST6, XPTHRUST6.length); 
		  
	   }
	   g.setTransform(at);
	   
	  
	   
//	   int x = (int)s.x;
//	   int y = (int)s.y;
//	   g.setColor(Color.red);
//	   g.fillOval(x - RADIUS, y - RADIUS, 2 * RADIUS, 2 * RADIUS);
//	   g.drawLine(x, y, x+3*RADIUS, y+3*RADIUS);	   
	   
   }
    public void drawBarrier(Graphics2D g){
        //AffineTransform at = g.getTransform();
        if(barriercount >0){
        g.setColor(new Color(255,193,37,70));
        g.fillOval(-10, -10, 20, 20);

        //System.out.println("Draw");
        }else if(barriercount == 0){
            barrier = true;
        }
    }


    private void shootBullet(){
	   Vector2D bV = new Vector2D(v);
	   bV.add(d, -200);
	   Vector2D bS = new Vector2D(s);
	   bS.add(d, -Radius()-1);
	   Bullet b = new Bullet (this.game,bS, bV);  
	   game.add(b);
	   SoundManager.fire();
	   SoundManager.play(SoundManager.fire); 
   }
   
   
private void YAMATOcannon(){

    if(shootcannon>0){
        Vector2D bV = new Vector2D(v);
        bV.add(d, -200);
        Vector2D bS = new Vector2D(s);
        bS.add(d, -Radius()-10);
        Cannon b = new Cannon (this.game, bS, bV);
        removeShootcannon();
        game.add(b);
    }
    SoundManager.bangSmall();
    SoundManager.play(SoundManager.bangSmall);
   }

public void hit() {
    if(barriercount>0){
       // barriercount--;
        dead = false;
    }else{
        dead = true;
    }
}
    public void hit2(){
        dead = true;
        shootcannon--;
    }

    @Override
    public double dist(GameObject obj) {
        return s.dist(obj.s);
    }

    @Override
    public Vector2D to(GameObject target) {
        return new Vector2D(target.v.x-this.v.x, target.v.y-this.v.y);
    }

    @Override
    public double radius() {
        return 0;
    }
    public double Radius() {
        // TODO Auto-generated method stub
        return RADIUS;
    }

    public int getShootcannon(){
        return shootcannon;
    }
    public void addShootcannon(){
        shootcannon-=1;
    }
    public void removeShootcannon(){
        shootcannon--;
    }
}
